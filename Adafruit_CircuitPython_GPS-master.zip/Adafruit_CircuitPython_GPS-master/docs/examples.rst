Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/gps_simpletest.py
    :caption: examples/gps_simpletest.py
    :linenos:
